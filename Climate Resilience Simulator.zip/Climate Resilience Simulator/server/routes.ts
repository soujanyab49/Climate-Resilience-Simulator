import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

const API_TIMEOUT = 5000;

function fetchWithTimeout(url: string, timeout = API_TIMEOUT): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  return fetch(url, { signal: controller.signal }).finally(() => clearTimeout(id));
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/mapbox/token", (_req, res) => {
    const token = process.env.MAPBOX_ACCESS_TOKEN;
    if (!token) {
      return res.status(500).json({ error: "Mapbox token not configured" });
    }
    res.json({ token });
  });

  app.get("/api/mapbox/geocode", async (req, res) => {
    const query = req.query.q as string;
    const token = process.env.MAPBOX_ACCESS_TOKEN;
    if (!query || !token) {
      return res.json({ features: [] });
    }
    try {
      const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(query)}.json?access_token=${token}&country=US&types=place,locality,neighborhood&limit=5`;
      const response = await fetchWithTimeout(url);
      if (!response.ok) {
        return res.status(response.status).json({ error: "Geocoding service error", features: [] });
      }
      const data = await response.json();
      res.json(data);
    } catch (err: any) {
      const isTimeout = err?.name === "AbortError";
      res.status(isTimeout ? 504 : 500).json({
        error: isTimeout ? "Geocoding request timed out" : "Geocoding failed",
        features: [],
      });
    }
  });

  app.get("/api/climate/data", async (req, res) => {
    const lat = parseFloat(req.query.lat as string);
    const lon = parseFloat(req.query.lon as string);
    if (isNaN(lat) || isNaN(lon)) {
      return res.status(400).json({ error: "Invalid coordinates" });
    }

    const results: { weather?: any; elevation?: any; solar?: any } = {};

    const fetches = [
      fetchWithTimeout(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m&daily=temperature_2m_max,temperature_2m_min&timezone=auto`)
        .then(r => r.json()).then(d => { results.weather = d; }).catch(() => { results.weather = null; }),
      fetchWithTimeout(`https://api.open-meteo.com/v1/elevation?latitude=${lat}&longitude=${lon}`)
        .then(r => r.json()).then(d => { results.elevation = d; }).catch(() => { results.elevation = null; }),
      fetchWithTimeout(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=shortwave_radiation_sum&timezone=auto`)
        .then(r => r.json()).then(d => { results.solar = d; }).catch(() => { results.solar = null; }),
    ];

    await Promise.all(fetches);
    res.json(results);
  });

  return httpServer;
}
